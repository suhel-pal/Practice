package com.scb.cms.cmrs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CmrsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CmrsApplication.class, args);
	}

}
